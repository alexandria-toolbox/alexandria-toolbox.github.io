classdef ss
    

    % ss stands for state-space
    % A class containing static methods for state-space model utilities

    
    %---------------------------------------------------
    % Methods
    %---------------------------------------------------
    

    methods(Static)
        
        
        function [Z_tt Z_tt1 Ups_tt Ups_tt1] = kalman_filter(X, A, Omega, C, B, Upsilon, T, n, k)
            
            % [Z_tt Z_tt1 Ups_tt Ups_tt1] = kalman_filter(X, A, Omega, C, B, Upsilon, T, n, k)
            % Kalman filter to estimate the state variables of a general state-space model
            %
            % parameters:
            % X : matrix of size (T,n)
            %     matrix of observed variables
            % A : matrix of size (n,k,T)
            %     matrix of coefficients on observation equation
            % Omega : matrix of size (n,n,T)
            %     variance-covariance matrix of observation errors
            % C : matrix of size (T,k)
            %     intercept on observation equation  
            % B : matrix of size (k,k,T)
            %     matrix of coefficients on state equation        
            % Upsilon : matrix of size (k,k,T)
            %     variance-covariance matrix of state errors      
            % T : int
            %     number of sample periods          
            % n : int
            %     dimension of observation vector 
            % k : int
            %     dimension of state vector 
            % 
            % returns:
            % Z_tt : matrix of size (T,k)
            %     matrix of state values z_t|t          
            % Z_tt1 : matrix of size (T,k)
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t-1  
        
            % initiate values
            z_t1t1 = zeros(k,1);
            Upsilon_t1t1 = zeros(k,k);
            Z_tt = zeros(T,k);
            Z_tt1 = zeros(T,k);
            Ups_tt = zeros(k,k,T);
            Ups_tt1 = zeros(k,k,T);
            % Kalman recursions
            for t=1:T
                % period-specific parameters
                x_t = X(t,:)';
                A_t = A(:,:,t);
                Omega_t = Omega(:,:,t);
                c_t = C(t,:)';
                B_t = B(:,:,t);
                Upsilon_t = Upsilon(:,:,t);
                % step 1
                z_tt1 = c_t + B_t * z_t1t1;
                % step 2
                Upsilon_tt1 = B_t * Upsilon_t1t1 * B_t' + Upsilon_t;
                % step 3
                x_tt1 = A_t * z_tt1;
                % step 4
                Omega_tt1 = A_t * Upsilon_tt1 * A_t' + Omega_t;
                % Phi_t computation
                Phi_t = Upsilon_tt1 * A_t' / Omega_tt1;
                % step 5
                z_tt = z_tt1 + Phi_t * (x_t - x_tt1);
                % step 6
                Upsilon_tt = Upsilon_tt1 - Phi_t * Omega_tt1 * Phi_t';
                % record and update for incoming period
                Z_tt(t,:) = z_tt';
                Z_tt1(t,:) = z_tt1';
                z_t1t1 = z_tt;
                Ups_tt(:,:,t) = Upsilon_tt;
                Ups_tt1(:,:,t) = Upsilon_tt1;
                Upsilon_t1t1 = Upsilon_tt;
            end
        end

        
        function [Z] = backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, k)
            
            % [Z] = backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, k)
            % Backward pass of Carter-Kohn algorithm (algorithm k.2)
            %
            % parameters:
            % Z_tt : matrix of size (T,k)
            %     matrix of state values z_t|t          
            % Z_tt1 : matrix of size (T,k)
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t-1
            % B : matrix of size (k,k,T)
            %     matrix of coefficients on state equation  
            % T : int
            %     number of sample periods           
            % k : int
            %     dimension of state vector             
            % 
            % returns:
            % Z : matrix of size (T,k)
            %     matrix of sampled values for the state variables     
        
            % initiate values
            Z = zeros(T,k);
            % final period sampling
            z_TT = Z_tt(end,:)';
            Upsilon_TT = Ups_tt(:,:,end);
            Z(end,:) = rn.multivariate_normal(z_TT, Upsilon_TT);
            % backward pass, other periods
            for t=T-1:-1:1
                % period-specific parameters
                B_t1 = B(:,:,t+1);
                z_tt = Z_tt(t,:)';
                z_t1t = Z_tt1(t+1,:)';
                Upsilon_tt = Ups_tt(:,:,t);
                Upsilon_t1t = Ups_tt1(:,:,t+1);
                z_t1 = Z(t+1,:)';
                % Xi_t computation
                Xi_t = Upsilon_tt * B_t1' / Upsilon_t1t;
                % step 1
                z_bar_tt1 = z_tt + Xi_t * (z_t1 - z_t1t);
                % step 2
                Upsilon_bar_tt1 = Upsilon_tt - Xi_t * B_t1 * Upsilon_tt;
                % step 3
                Z(t,:) = rn.multivariate_normal(z_bar_tt1, Upsilon_bar_tt1);   
            end       
        end        
        
        
        function [Z_tt Z_tt1 Ups_tt Ups_tt1] = conditional_forecast_kalman_filter(X, A, Omega, C, B, Upsilon, z_00, Upsilon_00, T, n, k)
            
            % [Z_tt Z_tt1 Ups_tt Ups_tt1] = conditional_forecast_kalman_filter(X, A, Omega, C, B, Upsilon, z_00, Upsilon_00, T, n, k)
            % Kalman filter to estimate the state variables of a conditional forecast state-space model
            %
            % parameters:
            % X : matrix of size (T,n)
            %     matrix of observed variables
            % A : matrix of size (n,k)
            %     matrix of coefficients on observation equation
            % Omega : matrix of size (T,n)
            %     variance-covariance matrix of observation errors
            % C : matrix of size (T,k)
            %     intercept on observation equation  
            % B : matrix of size (k,k)
            %     matrix of coefficients on state equation        
            % Upsilon : matrix of size (k,k,T)
            %     variance-covariance matrix of state errors
            % z_00 : matrix of size (k,1)
            %     initial conditions for state variables (mean)    
            % Upsilon_00 : matrix of size (k,k)
            %     initial conditions for state variables (variance-covariance)              
            % T : int
            %     number of sample periods          
            % n : int
            %     dimension of observation vector 
            % k : int
            %     dimension of state vector 
            % 
            % returns:
            % Z_tt : matrix of size (T,k)
            %     matrix of state values z_t|t          
            % Z_tt1 : matrix of size (T,k)
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t-1  
        
            % initiate values
            z_t1t1 = z_00;
            Upsilon_t1t1 = Upsilon_00;
            Z_tt = zeros(T,k);
            Z_tt1 = zeros(T,k);
            Ups_tt = zeros(k,k,T);
            Ups_tt1 = zeros(k,k,T);
            % Kalman recursions
            for t=1:T
                % period-specific parameters
                x_t = X(t,:)';
                Omega_t = diag(Omega(t,:));
                c_t = C(t,:)';
                Upsilon_t = Upsilon(:,:,t);
                % step 1
                z_tt1 = c_t + B * z_t1t1;
                % step 2
                Upsilon_tt1 = B * Upsilon_t1t1 * B' + Upsilon_t;
                % step 3
                x_tt1 = A * z_tt1;
                % step 4
                Omega_tt1 = A * Upsilon_tt1 * A' + Omega_t;
                % Phi_t computation
                Phi_t = Upsilon_tt1 * A' / Omega_tt1;
                % step 5
                z_tt = z_tt1 + Phi_t * (x_t - x_tt1);
                % step 6
                Upsilon_tt = Upsilon_tt1 - Phi_t * Omega_tt1 * Phi_t';
                % record and update for incoming period
                Z_tt(t,:) = z_tt';
                Z_tt1(t,:) = z_tt1';
                z_t1t1 = z_tt;
                Ups_tt(:,:,t) = Upsilon_tt;
                Ups_tt1(:,:,t) = Upsilon_tt1;
                Upsilon_t1t1 = Upsilon_tt;
            end
        end        
        
        
        function [Z] = static_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, k)
            
            % [Z] = static_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, k)
            % Backward pass of Carter-Kohn algorithm (algorithm k.2) with static B
            %
            % parameters:
            % Z_tt : matrix of size (T,k)
            %     matrix of state values z_t|t          
            % Z_tt1 : matrix of size (T,k)
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t-1
            % B : matrix of size (k,k)
            %     matrix of coefficients on state equation  
            % T : int
            %     number of sample periods           
            % k : int
            %     dimension of state vector             
            % 
            % returns:
            % Z : matrix of size (T,k)
            %     matrix of sampled values for the state variables     
        
            % initiate values
            Z = zeros(T,k);
            % final period sampling
            z_TT = Z_tt(end,:)';
            Upsilon_TT = Ups_tt(:,:,end);
            Z(end,:) = rn.multivariate_normal(z_TT, Upsilon_TT);
            % backward pass, other periods
            for t=T-1:-1:1
                % period-specific parameters
                z_tt = Z_tt(t,:)';
                z_t1t = Z_tt1(t+1,:)';
                Upsilon_tt = Ups_tt(:,:,t);
                Upsilon_t1t = Ups_tt1(:,:,t+1) + 1e-10 * eye(k);
                z_t1 = Z(t+1,:)';
                % Xi_t computation
                Xi_t = Upsilon_tt * B' / Upsilon_t1t;
                % step 1
                z_bar_tt1 = z_tt + Xi_t * (z_t1 - z_t1t);
                % step 2
                Upsilon_bar_tt1 = Upsilon_tt - Xi_t * B * Upsilon_tt;
                % step 3
                Z(t,:) = rn.multivariate_normal(z_bar_tt1, Upsilon_bar_tt1);   
            end
        end         
        
        
        function [Z_tt Z_tt1 Ups_tt Ups_tt1] = varma_forward_pass(X, A, B, Upsilon, z_00, Upsilon_00, T, n, k)
            
            % varma_forward_pass(X, A, B, Upsilon, z_00, Upsilon_00, T, n, k)
            % forward pass for the state variables of a varma model
            %
            % parameters:
            % X : matrix of size (T,n)
            %     matrix of observed variables
            % A : matrix of size (n,k,T)
            %     matrix of coefficients on observation equation
            % B : matrix of size (k,k,T)
            %     matrix of coefficients on state equation        
            % Upsilon : matrix of size (k,k,T)
            %     variance-covariance matrix of state errors   
            % z_00 : matrix of size (k,1)
            %     initial conditions for state variables (mean)    
            % Upsilon_00 : matrix of size (k,k)
            %     initial conditions for state variables (variance-covariance)             
            % T : int
            %     number of sample periods          
            % n : int
            %     dimension of observation vector 
            % k : int
            %     dimension of state vector 
            % 
            % returns:
            % Z_tt : matrix of size (T,k)
            %     matrix of state values z_t|t          
            % Z_tt1 : matrix of size (T,k)
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t-1  
        
            % initiate values
            z_t1t1 = z_00;
            Upsilon_t1t1 = Upsilon_00;
            Z_tt = zeros(T,k);
            Z_tt1 = zeros(T,k);
            Ups_tt = zeros(k,k,T);
            Ups_tt1 = zeros(k,k,T);
            % Kalman recursions
            for t=1:T
                % period-specific parameters
                x_t = X(t,:)';
                % step 1
                z_tt1 = B * z_t1t1;
                % step 2
                Upsilon_tt1 = B * Upsilon_t1t1 * B' + Upsilon;
                % step 3
                x_tt1 = A * z_tt1;
                % step 4
                Omega_tt1 = A * Upsilon_tt1 * A';
                % Phi_t computation
                Phi_t = Upsilon_tt1 * A' / Omega_tt1;
                % step 5
                z_tt = z_tt1 + Phi_t * (x_t - x_tt1);
                % step 6
                Upsilon_tt = Upsilon_tt1 - Phi_t * Omega_tt1 * Phi_t';
                % record and update for incoming period
                Z_tt(t,:) = z_tt';
                Z_tt1(t,:) = z_tt1';
                z_t1t1 = z_tt;
                Ups_tt(:,:,t) = Upsilon_tt;
                Ups_tt1(:,:,t) = Upsilon_tt1;
                Upsilon_t1t1 = Upsilon_tt;
            end
        end        
     

        function [Z] = varma_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, k)
            
            % varma_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, k)
            % backward pass for the state variables of a varma model
            %
            % parameters:
            % Z_tt : matrix of size (T,k)
            %     matrix of state values z_t|t          
            % Z_tt1 : matrix of size (T,k)
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (k,k,T)
            %     matrix of state variance Upsilon_t|t-1
            % B : matrix of size (k,k)
            %     matrix of coefficients on state equation  
            % T : int
            %     number of sample periods           
            % k : int
            %     dimension of state vector             
            % 
            % returns:
            % Z : matrix of size (T,k)
            %     matrix of sampled values for the state variables     
        
            % initiate values
            Z = zeros(T,k);
            % final period sampling
            z_TT = Z_tt(end,:)';
            Upsilon_TT = Ups_tt(:,:,end);
            Z(end,:) = rn.multivariate_normal(z_TT, Upsilon_TT);
            % backward pass, other periods
            for t=T-1:-1:1
                % period-specific parameters
                z_tt = Z_tt(t,:)';
                z_t1t = Z_tt1(t+1,:)';
                Upsilon_tt = Ups_tt(:,:,t);
                Upsilon_t1t = Ups_tt1(:,:,t+1) + 1e-10 * eye(k);
                z_t1 = Z(t+1,:)';
                % Xi_t computation
                Xi_t = Upsilon_tt * B' / Upsilon_t1t;
                % step 1
                z_bar_tt1 = z_tt + Xi_t * (z_t1 - z_t1t);
                % step 2
                Upsilon_bar_tt1 = Upsilon_tt - Xi_t * B * Upsilon_tt;
                % step 3
                Z(t,:) = rn.multivariate_normal(z_bar_tt1, Upsilon_bar_tt1);   
            end
        end


        function [Z_tt Z_tt1 Ups_tt Ups_tt1] = dfm_forward_pass(x_, Lambda, B, Upsilon, z_00, Upsilon_00, T, m, n, s, r, J)
            
            % dfm_forward_pass(x_, Lambda, B, Upsilon, z_00, Upsilon_00, T, m, n, s, r, J)
            % forward pass for the state variables of a dfm model
            % 
            % parameters:
            % x_: list of size (T)
            %     list of non-NaN data for each sample period, defined in (6.18.10)      
            % Lambda: matrix of size (n,m(s+1)+n(r+1))
            %     time invariant counterpart of matrix A_t, defined in (6.18.39)
            % B: matrix of size (m(s+1)+n(r+1),m(s+1)+n(r+1))
            %     companion matrix B, defined in (6.18.39)        
            % z_00: matrix of size (m(s+1)+n(r+1),)
            %     vector of mean for initial factor value
            % Upsilon_00: matrix of size (m(s+1)+n(r+1),m(s+1)+n(r+1))
            %     matrix of variance for initial factor value  
            % T: int
            %     total number of sample periods, defined in (6.18.1)
            % m: int
            %     number of fundamental factors in the model, defined in (6.18.1)   
            % n: int
            %     number of endogenous variables, defined in (6.18.1)
            % s: int
            %     maximum number of factor lags, defined in (6.18.38)
            % r: int
            %     number of lags in the residual AR process, defined in (6.18.7) 
            % J: list of size (T)
            %     cell of non-NaN variables for each sample period, defined in (6.18.3)        
            % 
            % returns:
            % Z_tt : matrix of size (m(s+1)+n(r+1),)
            %     matrix of state values z_t|t
            % Z_tt1 : matrix of size (T,q(r+1))
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (q(r+1),q(r+1),T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (q(r+1),q(r+1),T)
            %     matrix of state variance Upsilon_t|t-1            
           
            % initiate values
            f_dim = m * (s + 1) + n * (r + 1);
            z_t1t1 = z_00;
            Upsilon_t1t1 = Upsilon_00;
            Z_tt = zeros(T,f_dim);
            Z_tt1 = zeros(T,f_dim);
            Ups_tt = zeros(f_dim,f_dim,T);
            Ups_tt1 = zeros(f_dim,f_dim,T);
            % Kalman recursions
            for t=1:T
                % period-specific parameters
                x_t = x_{t}';
                A_t = Lambda(J{t},:);
                % step 1
                z_tt1 = B * z_t1t1;        
                % step 2
                Upsilon_tt1 = B * Upsilon_t1t1 * B' + Upsilon;        
                % step 3
                x_tt1 = A_t * z_tt1;      
                % step 4
                Omega_tt1 = A_t * Upsilon_tt1 * A_t';  
                % Phi_t computation
                Phi_t = Upsilon_tt1 * A_t' / Omega_tt1;        
                % step 5
                z_tt = z_tt1 + Phi_t * (x_t - x_tt1);
                % step 6
                Upsilon_tt = Upsilon_tt1 - Phi_t * Omega_tt1 * Phi_t';
                % record and update for incoming period
                Z_tt(t,:) = z_tt';
                Z_tt1(t,:) = z_tt1';
                z_t1t1 = z_tt;
                Ups_tt(:,:,t) = Upsilon_tt;
                Ups_tt1(:,:,t) = Upsilon_tt1;
                Upsilon_t1t1 = Upsilon_tt;
            end
        end

        
        function [Z] = dfm_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, m, s, n, r)
            
            % dfm_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, m, s, n, r)
            % backward pass for the state variables of a dfm model
            % 
            % parameters:
            % Z_tt : ndarray of shape (m(s+1)+n(r+1),)
            %     matrix of state values z_t|t
            % Z_tt1 : ndarray of shape (T,q(r+1))
            %     matrix of state values z_t|t-1 
            % Ups_tt : ndarray of shape (q(r+1),q(r+1),T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : ndarray of shape (q(r+1),q(r+1),T)
            %     matrix of state variance Upsilon_t|t-1  
            % B: ndarray of shape (m(s+1)+n(r+1),m(s+1)+n(r+1))
            %     companion matrix B, defined in (6.18.39) 
            % T: int
            %     total number of sample periods, defined in (6.18.1)
            % m: int
            %     number of fundamental factors in the model, defined in (6.18.1)  
            % s: int
            %     maximum number of factor lags, defined in (6.18.38)
            % n: int
            %     number of endogenous variables, defined in (6.18.1)        
            % r: int
            %     number of lags in the residual AR process, defined in (6.18.7)       
            % 
            % returns:
            % Z : matrix of size (T,m(s+1)+n(r+1))
            %     matrix of sampled values for the state variables           
            
            % initiate values
            f_dim = m * (s + 1) + n * (r + 1);
            Z = zeros(T,f_dim);
            % final period sampling
            z_TT = Z_tt(end,:)';
            Upsilon_TT = Ups_tt(:,:,end) + 1e-8 * eye(f_dim);
            Z(end,:) = rn.multivariate_normal(z_TT, Upsilon_TT);
            % backward pass, other periods
            for t=T-1:-1:1
                % period-specific parameters
                z_tt = Z_tt(t,:)';
                z_t1t = Z_tt1(t+1,:)';
                Upsilon_tt = Ups_tt(:,:,t);
                Upsilon_t1t = Ups_tt1(:,:,t+1) + 1e-8 * eye(f_dim);
                z_t1 = Z(t+1,:)';
                % Xi_t computation
                Xi_t = Upsilon_tt * B' / Upsilon_t1t;
                % step 1
                z_bar_tt1 = z_tt + Xi_t * (z_t1 - z_t1t);
                % step 2
                Upsilon_bar_tt1 = Upsilon_tt - Xi_t * B * Upsilon_tt + 1e-8 * eye(f_dim);
                % step 3
                Z(t,:) = rn.multivariate_normal(z_bar_tt1, Upsilon_bar_tt1); 
            end
        end


        function [Z_tt Z_tt1 Ups_tt Ups_tt1 ] = epsilon_forward_pass(x_, lamda, W, A, B, Upsilon, z_00, Upsilon_00, T, l, r, J)
            
            % dfm_forward_pass(x_, Lambda, B, Upsilon, z_00, Upsilon_00, T, m, n, s, r, J)
            % forward pass for the state variables of a dfm model
            % 
            % parameters:
            % x_: struct of size (T,1)
            %     structure of non-NaN data for each sample period, defined in (6.18.10)      
            % lamda: matrix of size (l,m(s+1))
            %     matrix of loadings, restricted equations, defined in theorem 18.1
            % W: matrix of size (T,m(s+1))
            %     lagged factor matrix, defined in (6.18.11)         
            % A: matrix of size (l,l(r+1))
            %     loadings on residuals, observation equation
            % B: matrix of size (m(s+1)+n(r+1),m(s+1)+n(r+1))
            %     companion matrix on residuals, state equation
            % z_00: matrix of size (l(r+1),)
            %     vector of mean for initial factor value
            % Upsilon_00: matrix of size (l(r+1),l(r+1))
            %     matrix of variance for initial factor value  
            % T: int
            %     total number of sample periods, defined in (6.18.1)
            % l: int
            %     total number of loadings regressors, defined in (6.18.11)  
            % r: int
            %     number of lags in the residual AR process, defined in (6.18.7) 
            % J: struct of size (T,1)
            %     strucrure of non-NaN variables for each sample period, defined in (6.18.3)        
            % 
            % returns:
            % Z_tt : matrix of size (T,l(r+1))
            %     matrix of state values z_t|t
            % Z_tt1 : matrix of size (T,l(r+1))
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (l(r+1),l(r+1),T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (l(r+1),l(r+1),T)
            %     matrix of state variance Upsilon_t|t-1      
        
            % initiate values
            f_dim = l * (r + 1); 
            z_t1t1 = z_00;
            Upsilon_t1t1 = Upsilon_00;
            Z_tt = zeros(T,f_dim);
            Z_tt1 = zeros(T,f_dim);
            Ups_tt = zeros(f_dim,f_dim,T);
            Ups_tt1 = zeros(f_dim,f_dim,T);
            % Kalman recursions
            for t=1:T
                % period-specific parameters   
                J_t = J{t}(J{t} <= l);
                x_t = x_{t}(1:numel(J_t))';
                f_t = lamda(J_t,:) * W(t,:)';
                x_t = x_t - f_t;
                A_t = A(J_t,:);
                % step 1
                z_tt1 = B * z_t1t1;
                % step 2
                Upsilon_tt1 = B * Upsilon_t1t1 * B' + Upsilon; 
                % if there are observations, run normal kalman steps
                if numel(J_t) > 0
                    % step 3
                    x_tt1 = A_t * z_tt1;   
                    % step 4
                    Omega_tt1 = A_t * Upsilon_tt1 * A_t' + 1e-10 * eye(numel(J_t));
                    % Phi_t computation
                    Phi_t = Upsilon_tt1 * A_t' / Omega_tt1; 
                    % step 5
                    z_tt = z_tt1 + Phi_t * (x_t - x_tt1);           
                    % step 6
                    Upsilon_tt = Upsilon_tt1 - Phi_t * Omega_tt1 * Phi_t'; 
                % if there are no observations, run naive forecasts
                else
                    % step 5
                    z_tt = z_tt1;        
                    % step 6
                    Upsilon_tt = Upsilon_tt1;
                end
                % record and update for incoming period
                Z_tt(t,:) = z_tt';
                Z_tt1(t,:) = z_tt1';
                z_t1t1 = z_tt;
                Ups_tt(:,:,t) = Upsilon_tt;
                Ups_tt1(:,:,t) = Upsilon_tt1;
                Upsilon_t1t1 = Upsilon_tt;                
            end       
        end


        function [Z] = epsilon_backward_pass(Z_tt, Z_tt1, Ups_tt, Ups_tt1, B, T, l, r)

            % Z_tt : matrix of size (T,l(r+1))
            %     matrix of state values z_t|t
            % Z_tt1 : matrix of size (T,l(r+1))
            %     matrix of state values z_t|t-1 
            % Ups_tt : matrix of size (l(r+1),l(r+1),T)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (l(r+1),l(r+1),T)
            %     matrix of state variance Upsilon_t|t-1     
            % B: matrix of size (m(s+1)+n(r+1),m(s+1)+n(r+1))
            %     companion matrix on residuals, state equation    
            % T: int
            %     total number of sample periods, defined in (6.18.1)
            % l: int
            %     total number of loadings regressors, defined in (6.18.11)  
            % r: int
            %     number of lags in the residual AR process, defined in (6.18.7)  
            % 
            % returns:
            % Z : matrix of size (T,l(r+1))
            %     matrix of sampled values for the state variables           
        
            % initiate values
            f_dim = l * (r + 1);
            Z = zeros(T,f_dim);
            % final period sampling
            z_TT = Z_tt(end,:)';
            Upsilon_TT = Ups_tt(:,:,end) + 1e-10 * eye(f_dim);
            Z(end,:) = rn.multivariate_normal(z_TT, Upsilon_TT);
            % backward pass, other periods
            for t=T-1:-1:1
                % period-specific parameters
                z_tt = Z_tt(t,:)';
                z_t1t = Z_tt1(t+1,:)';
                Upsilon_tt = Ups_tt(:,:,t);
                Upsilon_t1t = Ups_tt1(:,:,t+1);  
                z_t1 = Z(t+1,:)';
                % Xi_t computation
                Xi_t = Upsilon_tt * B' / Upsilon_t1t;
                % step 1
                z_bar_tt1 = z_tt + Xi_t * (z_t1 - z_t1t);
                % step 2
                Upsilon_bar_tt1 = Upsilon_tt - Xi_t * B * Upsilon_tt + 1e-10 * eye(f_dim);
                % step 3
                Z(t,:) = rn.multivariate_normal(z_bar_tt1, Upsilon_bar_tt1);
            end
        end


        function [Gamma_tt, Gamma_tt1, Ups_tt, Ups_tt1] = mfbvar_forward_pass(yo_, L_, F, mu_, n, p, Upsilon, T_, gamma_00, Upsilon_00)
              
            % mfbvar_forward_pass(yo_, L_, F, mu_, n, p, Upsilon, T_, gamma_00, Upsilon_00)
            % forward pass for the state variables of the MF-BVAR model
            % 
            % parameters:
            % yo_: cell of size (T_)
            %     cell of non-NaN data yo_t for each sample period, defined in (6.17.16) 
            % L_: cell of size (T_)
            %     cell of selection matrices L_t for each sample period, defined in (6.17.21)         
            % F: matrix of size (n*p,n*p)
            %     companion matrix of VAR coefficients, defined in (6.17.20)
            % mu_: cell of size (T_)
            %     list of endogenous vectors for each sample period, defined in (6.17.19) 
            % n : int
            %     number of endogenous variables, defined in (6.17.1)
            % p : int
            %     number of lags in the VAR model, defined in (6.17.1)
            % Upsilon: matrix of size (n*p,n*p)
            %     variance-covariance matrix for state equation
            % T_ : int
            %     number of sample periods, including initial conditions
            % gamma_00: matrix of size (n*p,)
            %     vector of mean for initial factor value
            % Upsilon_00: matrix of size (n*p,n*p)
            %     matrix of variance for initial factor value  
            % 
            % returns:
            % Gamma_tt : matrix of size (T_,n*p)
            %     matrix of state values gamma_t|t
            % Gamma_tt1 : matrix of size (T_,n*p)
            %     matrix of state values gamma_t|t-1 
            % Ups_tt : matrix of size (n*p,n*p,T_)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (n*p,n*p,T_)
            %     matrix of state variance Upsilon_t|t-1        
            
            % initiate values
            f_dim = n * p;
            gamma_t1t1 = gamma_00;
            Upsilon_t1t1 = Upsilon_00;
            Gamma_tt = zeros(T_,f_dim);
            Gamma_tt1 = zeros(T_,f_dim);
            Ups_tt = zeros(f_dim,f_dim,T_);
            Ups_tt1 = zeros(f_dim,f_dim,T_);
            % Kalman recursions
            for t=1:T_
                % period-specific parameters
                yo_t = yo_{t};
                L_t = L_{t};
                mu_t = mu_(t,:)';
                % step 1
                gamma_tt1 = mu_t + F * gamma_t1t1;
                % step 2
                Upsilon_tt1 = F * Upsilon_t1t1 * F' + Upsilon;
                % step 3
                yo_tt1 = L_t * gamma_tt1;
                % step 4
                Omega_tt1 = L_t * Upsilon_tt1 * L_t';                    
                % Phi_t computation
                Phi_t = Upsilon_tt1 * L_t' / Omega_tt1;   
                % step 5
                gamma_tt = gamma_tt1 + Phi_t * (yo_t - yo_tt1);        
                % step 6
                Upsilon_tt = Upsilon_tt1 - Phi_t * Omega_tt1 * Phi_t';  
                % record and update for incoming period
                Gamma_tt(t,:) = gamma_tt';
                Gamma_tt1(t,:) = gamma_tt1';
                gamma_t1t1 = gamma_tt;
                Ups_tt(:,:,t) = Upsilon_tt;
                Ups_tt1(:,:,t) = Upsilon_tt1;
                Upsilon_t1t1 = Upsilon_tt;
            end
        end


        function [Gamma] = mfbvar_backward_pass(Gamma_tt, Gamma_tt1, Ups_tt, Ups_tt1, F, T_, n, p)
              
            % mfbvar_forward_pass(yo_, L_, F, mu_, n, p, Upsilon, T_, gamma_00, Upsilon_00)
            % forward pass for the state variables of the MF-BVAR model
            % 
            % parameters:
            % Gamma_tt : matrix of size (T_,n*p)
            %     matrix of state values gamma_t|t
            % Gamma_tt1 : matrix of size (T_,n*p)
            %     matrix of state values gamma_t|t-1 
            % Ups_tt : matrix of size (n*p,n*p,T_)
            %     matrix of state variance Upsilon_t|t       
            % Ups_tt1 : matrix of size (n*p,n*p,T_)
            %     matrix of state variance Upsilon_t|t-1  
            % F: matrix of size (n*p,n*p)
            %     companion matrix of VAR coefficients, defined in (6.17.20)        
            % T_ : int
            %     number of sample periods, including initial conditions        
            % n : int
            %     number of endogenous variables, defined in (6.17.1)
            % p : int
            %     number of lags in the VAR model, defined in (6.17.1)        
            % 
            % returns:
            % Gamma : matrix of size (T_,n*p)
            %     matrix of sampled values for the state variables        
        
            % initiate values
            f_dim = n * p;
            Gamma = zeros(T_,f_dim);
            % final period sampling
            gamma_TT = Gamma_tt(end,:)';
            Upsilon_TT = Ups_tt(:,:,end) + 1e-8 * eye(f_dim);
            Gamma(end,:) = rn.multivariate_normal(gamma_TT, Upsilon_TT);
            % backward pass, other periods
            for t=T_-1:-1:1
                % period-specific parameters
                gamma_tt = Gamma_tt(t,:)';
                gamma_t1t = Gamma_tt1(t+1,:)';
                Upsilon_tt = Ups_tt(:,:,t);
                Upsilon_t1t = Ups_tt1(:,:,t+1) + 1e-8 * eye(f_dim);
                gamma_t1 = Gamma(t+1,:)';
                % Xi_t computation
                Xi_t = Upsilon_tt * F' / Upsilon_t1t;
                % step 1
                gamma_bar_tt1 = gamma_tt + Xi_t * (gamma_t1 - gamma_t1t);
                % step 2
                Upsilon_bar_tt1 = Upsilon_tt - Xi_t * F * Upsilon_tt + 1e-8 * eye(f_dim);
                % step 3
                Gamma(t,:) = rn.multivariate_normal(gamma_bar_tt1, Upsilon_bar_tt1); 
            end
        end


    end
    
    
end
        